Hi there,

Thank for purchasing and using Boby
If there is a problem, question, or anything about my fonts, please sent an email to
hi@calligraphyfonts.net



Here's How to Enable OpenType Features in Word, Photoshop and Illustrator


https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,

CalligraphyFonts.net